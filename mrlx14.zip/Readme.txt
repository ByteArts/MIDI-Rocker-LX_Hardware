File List:
MRLX14.DRL - Binary Excellon format drill file
MRLX14.DRR - drill report file
MRLX14.GBL - Gerber bottom copper layer
MRLX14.GBS - Gerber bottom soldermask layer
MRLX14.GD1 - Gerber drill drawing
MRLX14.GG1 - Gerber drill guide
MRLX14.GM1 - Gerber mechanical drawing (board outline)
MRLX14.GTL - Gerber top copper layer
MRLX14.GTO - Gerber top silkscreen layer
MRLX14.GTP - Gerber top paste mask layer
MRLX14.GTS - Gerber top soldermask layer
MRLX14.PIK - CSV format pick and place file
MRLX14.TXT - ASCII format drill file
READMEA.TXT - This file

Total: 14 Files 

Contact Info:
Scott Pinkham
scottp@ByteArts.com
406/624-9102
